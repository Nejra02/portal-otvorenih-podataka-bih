package com.example.projekatzavrsni.data.api.persons

data class PersonsApiResponse(
    val result: List<PersonInfo>
)