package com.example.projekatzavrsni.data.api.newborns

data class NewbornApiResponse(
    val result: List<NewbornInfo>
)
