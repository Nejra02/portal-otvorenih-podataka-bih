package com.example.projekatzavrsni.ui.theme

import androidx.compose.ui.graphics.Color

val White     = Color(0xFFFFFFFF)
val DirtyWhite = Color(0xFFEDEEEB)
val Grey = Color(0xFFCCC7BF)
val DarkGrey = Color(0xFF31393C)
val Blue = Color(0xFF3E96F4)