package com.example.projekatzavrsni.presentation.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.projekatzavrsni.presentation.viewmodel.NewbornViewModel



@Composable
fun StatisticsScreen(viewModel: NewbornViewModel = viewModel()) {
    Text("STATISTIKA LOADED")

}

