package com.example.projekatzavrsni.data.api

import com.example.projekatzavrsni.data.api.newborns.Newborns
import com.example.projekatzavrsni.data.api.persons.Persons
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitInstance {

    private const val BASE_URL = "https://odp.iddeea.gov.ba:8096/"
    private const val TOKEN = "Bearer eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIyMDMxIiwibmJmIjoxNzUwMzMxODEwLCJleHAiOjE3NTA0MTgyMTAsImlhdCI6MTc1MDMzMTgxMH0.qlpCZ2xuRAoWjj3OV37z6XQp7yIpiIYKmvXucd2PiN-qto1ZJdBjV7WlsUxaC39p_ECCynnws-fD7Z5e8UA0OA"

    private val authInterceptor = Interceptor { chain ->
        val request = chain.request().newBuilder()
            .addHeader("Authorization", TOKEN)
            .build()
        chain.proceed(request)
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .build()

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val api: Newborns by lazy {
        retrofit.create(Newborns::class.java)
    }

    val personsApi: Persons by lazy {
        retrofit.create(Persons::class.java)
    }

}
